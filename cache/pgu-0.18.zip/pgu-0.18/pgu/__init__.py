"""PGU is a collection of modules for writing games with PyGame.

* gui - A module for creating widget-based interfaces

"""

__version__ = '0.18'


