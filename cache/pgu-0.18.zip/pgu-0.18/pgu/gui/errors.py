# error.py

class PguError(Exception):
    pass

class StyleError(PguError):
    pass

